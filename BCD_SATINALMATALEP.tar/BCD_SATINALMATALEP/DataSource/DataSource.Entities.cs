using System;
using System.Collections.Generic;
using System.Linq;
using Bimser.CSP.DataSource.Api.Models;
using Newtonsoft.Json;

namespace BCD_SATINALMATALEP.DataSources
{
   ///RequestEntities
  
}