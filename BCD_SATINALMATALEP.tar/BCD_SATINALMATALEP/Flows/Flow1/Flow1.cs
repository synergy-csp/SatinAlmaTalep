using Bimser.CSP.Workflow.EventArguments;
using System;

namespace BCD_SATINALMATALEP.Flows
{
    public partial class Flow1
    {
        
    }
}