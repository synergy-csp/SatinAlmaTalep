export default class TalepForm extends Form.Designer {

}