import * as Controls from "@bimser/form-controls";
import "./TalepForm.css";

export class Designer extends Controls.Form {
    // properties
    Header1: Header;
NumberBox1: NumberBox;
NumberBox2: NumberBox;
NumberBox3: NumberBox;
ComboBox1: ComboBox;

}