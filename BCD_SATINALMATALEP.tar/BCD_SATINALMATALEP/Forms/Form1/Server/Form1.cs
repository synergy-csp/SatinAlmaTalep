using System;
using System.Collections.Generic;
using Bimser.CSP.FormControls.Common;
using Bimser.CSP.FormControls.Controls;
using Bimser.CSP.FormControls.Events;
using BCD_SATINALMATALEP.Entities;

namespace BCD_SATINALMATALEP.Forms {

    public partial class Form1 {

    }
}