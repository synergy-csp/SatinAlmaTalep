import * as Controls from "@bimser/form-controls";
import "./Form1.css";

export class Designer extends Controls.Form {
    // properties
    DataGrid1: DataGrid;
RelatedDocuments1: RelatedDocuments;
Header1: Header;
DocumentMetadata1: DocumentMetadata;
DocumentMetadata2: DocumentMetadata;
NumberBox1: NumberBox;
UserMetadata1: UserMetadata;
TextArea1: TextArea;
Divider1: Divider;
UserMetadata2: UserMetadata;
UserMetadata3: UserMetadata;
UserMetadata4: UserMetadata;
Label1: Label;
TextArea2: TextArea;

}